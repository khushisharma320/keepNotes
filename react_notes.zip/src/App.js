import Header from "./component/Header";
import Footer from "./component/Footer";
import CreateNote from "./component/CreateNote";
import Note from "./component/Note";
import "./App.css";
import { useState } from "react";

function App() {
  const [additem, setAdditem] = useState([]);
  
  function addNote(n){
    setAdditem((prevData)=>{
      return [...prevData, n];
    });
    
  }

  const onDelete= (id)=>{
    const updateData = additem.filter((elem,index)=> index !== id);
    setAdditem(updateData);


  }

  return <>
  <div className="App">
  <Header/>
  <CreateNote passNote = {addNote}/>
{
  additem.map((val, index)=>{
    return ( <Note key={index} id = {index} titl = {val.title} content = {val.content} deleteItem = {onDelete}/>);
  })
}
  <Footer/>
  </div>
   
  
  </>
   
  
}

export default App;
