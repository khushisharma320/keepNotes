import { useState } from "react"

export default function CreateNote({ passNote }) {
    const [note, setNote] = useState({ title: "", content: "" });
    const [expand, setExpand] = useState(false);

    function expandItem() {
        setExpand(true);
    }

    function backToNormal() {
        setExpand(false);
    }

    function InputEvent(event) {

        const { name, value } = event.target;

        setNote({ ...note, [name]: value, });


    }

    function addEvent(event) {
        event.preventDefault();
        passNote(note);
        setNote(
            { title: "", content: "" }
        )

    }



    return (
        <>

            <div className="card-body" onDoubleClick={backToNormal}>
                <form>
                    {expand ?
                        <input type="text" placeholder="Title" autoComplete="off" value={note.title} onChange={InputEvent} name="title" /> : null}<br />
                    <textarea rows="" column="" placeholder="Write a note....." value={note.content} onChange={InputEvent} name="content" onClick={expandItem} /><br />
                    {expand ?
                        <button className="btn btn-primary" onClick={addEvent}>Add</button> : null}
                </form>
            </div>

        </>
    )

}