import "bootstrap/dist/css/bootstrap.css"
export default function Header() {
    return (
        <>
            <nav className="navbar bg-dark">
                <div className="container-fluid">
                    <span style={{color: "white"}} className="navbar-brand mb-0 h1">Google keep</span>
                </div>
            </nav>
        </>
    )

}

